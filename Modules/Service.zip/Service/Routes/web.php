<?php

use Illuminate\Support\Facades\Route;
use Modules\Service\Http\Controllers\ServiceController;

Route::prefix('admin')->middleware(['auth:admin', 'set_lang'])->group(function () {
    // Category Routes
    Route::prefix('service')->group(function () {
        Route::get('/', [ServiceController::class, 'index'])->name('module.service.index');
        Route::get('/add', [ServiceController::class, 'create'])->name('module.service.create');
        Route::post('/add', [ServiceController::class, 'store'])->name('module.service.store');
        Route::get('/edit/{service}', [ServiceController::class, 'edit'])->name('module.service.edit');
        Route::put('/update/{service}', [ServiceController::class, 'update'])->name('module.service.update');
        Route::get('/{service:slug}/show', [ServiceController::class, 'show'])->name('module.service.show');
        Route::delete('/destroy/{service}', [ServiceController::class, 'destroy'])->name('module.service.destroy');
        Route::post('/service/update/order', [ServiceController::class, 'updateOrder'])->name('module.service.updateOrder');
        Route::get('/status/change', [ServiceController::class, 'status_change'])->name('module.service.status.change');
    });

});
Route::get('/get-sub-services/{category_id}', [ServiceController::class, 'getSubcategories']);
