<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Modules\Coupon\Entities\Coupon;
use App\Http\Controllers\Controller;
use Darryldecode\Cart\CartCondition;
use Modules\Attribute\Entities\AttributeValue;
use Modules\Product\Entities\Product;
use Auth;

class AuthController extends Controller
{
   public function index(Request $request){
        return view('frontend.welcome');
   }
}
