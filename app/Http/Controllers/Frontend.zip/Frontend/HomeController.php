<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Modules\Service\Entities\Service;
use Modules\Category\Entities\Category;
use Modules\Brand\Entities\Brand;
use Modules\Location\Entities\City;
use Modules\Location\Entities\State;
use App\Models\User;
use App\Models\Slider;
use App\Models\Package;
use App\Models\Setting;
use App\Models\Favourite_product;
use App\Models\ReviewRating;
use App\Models\Contactus;
use App\Models\purchesd_packages;
use App\Models\User_package;
use App\Models\Faq;
use Carbon\Carbon;
use Modules\Coupon\Entities\Coupon;
use URL;
use DB;
use Auth;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(\Auth::check()) {
            $user = auth()->user();

            $user_id = $user->id;
        }else{
            $user_id = '';
        }

        $slider = Slider::get();

        $service = Service::limit(6)->get();

        $category = Category::limit(6)->get();

        foreach ($slider as $slider_1) {
            $slider_1["image"] = URL::to("/") . "/" . $slider_1->image;
        }

        $purchesd_packages = User_package::where("user_id", $user_id)->first();

        $packages = Package::where("status", 1)->get();

        if ($packages->count() > 0) {
            foreach ($packages as $package_1) {
                $package_1["duration"] = $package_1["duration"] . " MOnth";
                $package_1["car_cleaning"] =
                    $package_1["car_cleaning"] . " Car Cleaning Visits";
                $package_1["interior_cleaning"] =
                    $package_1["interior_cleaning"] . " Interior Cleaning";
                $package_1["vehicle_inspections"] =
                    $package_1["vehicle_inspections"] . " Vehicle Inspections";
            }

        }
        $data["packages"] = $packages;
        $data["slider"] = $slider;
        $data['service'] = $service;
        $data['category'] = $category;
        $data["package"] = $purchesd_packages;

        return view('frontend.welcome',$data);
    }


    // car service index
    public function serviceIndex()
    {
        $services = Service::get();
        $data['services'] = $services;
        return view('frontend.carservice',$data);
    }


    public function productIndex(){
        $products = Category::get();
        $data['products'] = $products;

        return view('frontend.productcategory' , $data);
    }

    public function couponIndex(){
        $coupons = Coupon::get();
        $data['coupons'] = $coupons;

        return view('frontend.promotions',$data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
